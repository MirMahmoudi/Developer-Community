import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      Hi front-end is ready for working
    </div>
  );
}

export default App;
